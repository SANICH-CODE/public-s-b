#include <iostream>
#include <string>

class CurrencyConverter {
public:
  void usd();
  void cny();
  void euro();
  void rub();
  void stop();
};


class errorCNY {
public:
    void print() {
    std::cout << std::endl
    << "Конвертация в CNY временно отключена." << std::endl
    << "Администратор: S.Nikitko" << std::endl
    << "Комментарий: Отключено по тех.причинам" << std::endl
    << "Причина: Отключено по тех.причинам" << std::endl
    << std::endl;
    }
};

class errorUSD {
public:
    void print() {
    std::cout << std::endl
    << "Конвертация в USD временно отключена." << std::endl
    << "Администратор: S.Nikitko" << std::endl
    << "Комментарий: Отключено по тех.причинам" << std::endl
    << "Причина: Отключено по тех.причинам" << std::endl
    << std::endl;
    }
};

