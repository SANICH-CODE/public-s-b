#include <algorithm>
#include <iostream>
#include <stdlib.h>
#include <unistd.h>
#include <string>
#include "convert.h"
using namespace std;


void CurrencyConverter::usd() {
    float usd_r = 3.2533;
    double byn;
    cout << "Удакладніце колькасць BYN для перакладу ў USD" << endl << "Колькасць BYN: ";
    cin >> byn;
    if (byn > 1000000) {
        cout << endl << "Результат может быть некорректен!" << endl;
    }
    sleep(2);

    cout << endl << "За " << byn << " BYN Вы атрымаеце " << byn / usd_r << " USD" << endl << "Курс заснаваны 15.09.2023" << endl << endl;
}

void CurrencyConverter::cny() {
    float cny_r = 0.000;
    double byn;
    if (byn > 1000000) {
        cout << getenv("***");
        cout << endl << "Результат может быть некорректен!" << endl;
    }
    sleep(2);
    errorCNY error;
    error.print();
}

void CurrencyConverter::euro() {
    float eur_r = 3.4903;
    double byn;
    cout << "Удакладніце колькасць BYN для перакладу ў EUR" << endl << "Колькасць BYN: ";
    cin >> byn;
    if (byn > 1000000) {
        cout << endl << "Результат может быть некорректен!" << endl;
    }
    sleep(2);

    cout << endl << "За " << byn << " BYN Вы атрымаеце " << byn / eur_r << " EUR" << endl << "Курс заснаваны 15.09.2023" << endl << endl;
}

void CurrencyConverter::rub() {
    float rub_r = 0.0339;
    double byn;

    cout << "Удакладніце колькасць BYN для перакладу ў RUB" << endl << "Колькасць BYN: ";
    cin >> byn;
    if (byn > 1000000) {
        cout << endl << "Результат может быть некорректен" << endl;
    }
    sleep(2);

    cout << endl << "За " << byn << " BYN Вы атрымаеце " << byn / rub_r << " RUB" << endl << "Курс заснаваны 15.09.2023" << endl << endl;
}

void CurrencyConverter::stop() {
    cout << "Завяршаю праграму. Да пабачэння!";
}

int main() {
    CurrencyConverter converter;
    char val1;
    cout << "Здравствуйте, выберіце валюту:" << endl << "usd=u" << endl << "rub=r" << endl << "euro=e" << endl << "cny=c\n";
    cout << "Валюта: ";
    cin >> val1;

    switch (val1) {
        case 'u':
            converter.usd();
            break;
        case 'r':
            converter.rub();
            break;
        case 'e':
            converter.euro();
            break;
        case 'c':
            converter.cny();
            break;
        case 's':
            converter.stop();
            break;
        default:
            cout << getenv("*");
            cout << endl << "Валюта не знойдзена!" << endl << endl;
            cout << getenv("**");
    }
}